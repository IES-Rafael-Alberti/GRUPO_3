# Peticiones FastAPI

## Setup

1. Install dependencies:

   ```sh
   pip install -r requirements.txt
   ```

2. Run the application for development:

   ```sh
   fastapi dev
   ```

---

Hecho por:

- Víctor Jiménez
- Alejandro Seoane
- Israel Valderrama
- Nicolas Ruiz
- Alejandro Díaz 
